package com.mirea.kt.practise8_calculator;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etDeposit, etInterestRate, etDuration;
    private Button btnCalculate;
    private TextView tvResult;
    private ScrollView scrollView;
    private LinearLayout llResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etDeposit = findViewById(R.id.et_deposit);
        etInterestRate = findViewById(R.id.et_interest_rate);
        etDuration = findViewById(R.id.et_duration);
        btnCalculate = findViewById(R.id.btn_calculate);
        tvResult = findViewById(R.id.tv_result);
        scrollView = findViewById(R.id.scroll_view);
        llResult = findViewById(R.id.ll_result);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
            }
        });
    }

    private void calculate() {
        String depositStr = etDeposit.getText().toString();
        String interestRateStr = etInterestRate.getText().toString();
        String durationStr = etDuration.getText().toString();

        if (TextUtils.isEmpty(depositStr)) {
            etDeposit.setError("Введите начальную сумму");
            return;
        }

        if (TextUtils.isEmpty(interestRateStr)) {
            etInterestRate.setError("Введите процентную ставку");
            return;
        }

        if (TextUtils.isEmpty(durationStr)) {
            etDuration.setError("Введите срок вклада в месяцах");
            return;
        }

        try {
            double deposit = Double.parseDouble(depositStr);
            double interestRate = Double.parseDouble(interestRateStr);
            int duration = Integer.parseInt(durationStr);

            List<Double> monthlyPayments = new ArrayList<>();
            double totalAmount = deposit;
            DecimalFormat decimalFormat = new DecimalFormat("#.##");

            int i = 0;
            while (i < duration) {
                double interest = (totalAmount * interestRate) / 100 / 12;
                double monthlyPayment = totalAmount / duration + interest;
                totalAmount += monthlyPayment;
                monthlyPayments.add(monthlyPayment);
                i++;
            }

            double totalInterest = totalAmount - deposit;
            double finalDeposit = totalAmount - monthlyPayments.get(monthlyPayments.size() - 1);
            tvResult.setText("Итоговая сумма: " + decimalFormat.format(totalAmount) + "\n" +
                    "Итоговый доход: " + decimalFormat.format(totalInterest) + "\n" +
                    "Итоговый вклад на момент последнего месяца: " + decimalFormat.format(finalDeposit));

            llResult.removeAllViews();
            for (i = 0; i < monthlyPayments.size(); i++) {
                TextView textView = new TextView(this);
                textView.setText("Месяц " + (i + 1) + ": " + decimalFormat.format(monthlyPayments.get(i)));
                llResult.addView(textView);
            }

            scrollView.setVisibility(View.VISIBLE);
        } catch (NumberFormatException e) {
            tvResult.setText("Проверьте правильность ввода");
        }
    }
}